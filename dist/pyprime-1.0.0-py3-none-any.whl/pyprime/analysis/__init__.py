"""PyPrime analysis subpackage."""
